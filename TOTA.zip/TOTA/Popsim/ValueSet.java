package Popsim;

public class ValueSet
{
    private String posName;
    private String negName;
    
    public ValueSet(String posName, String negName)
    {
        this.posName = posName;
        this.negName = negName;
    }
}
