public enum GameState
{
    START, COUNTRY_SELECT, GAME_PLAY
}
