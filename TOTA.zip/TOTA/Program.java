import java.awt.*;
import java.awt.event.*;
import java.awt.image.*;
import java.io.*;
import javax.swing.*;
import javax.imageio.*;
import Popsim.*;

public class Program extends JPanel
{
    // Tracks the state of the game
    private GameState gameState;
    private Font basedFont;
    
    // The Orion country object
    private Country orion;
    
    // There is only one at the moment
    private Country selectedCountry;
    
    public static void main(String[] args)
    {
        JFrame frame = new JFrame("Twilight of the Ages");
        frame.setExtendedState(JFrame.MAXIMIZED_BOTH);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.getContentPane().add(new Program());
        frame.setUndecorated(true);
        frame.setVisible(true);
    }
    
    public Program()
    {
        setBackground(new Color(50, 0, 0));
        gameState = GameState.START;
        
        
        // Gets font from file
        try
        {
            InputStream file = Program.class.getResourceAsStream("VCR_OSD_MONO_1.001.ttf");
            basedFont = Font.createFont(Font.TRUETYPE_FONT, file);
        } catch (Exception e)
        {
            
        }
        
        addMouseListener(new MouseInput());
        
        // Intro blurb
        String[] orionBlurb = { "'...and to these ends we decry the tyranny of Earther oppression, who have instigated their reign",
                                "by means of lawlessness and thuggery. And in doing so have robbed the human race of rights,",
                                "ones which are natural and ever present. They have robbed the individual of its autonomy",
                                "and entire worlds of their right to self-governance.'", "", "",
                                "Orion was founded in 2500 following the victory of the People's Revolutionary Front in the",
                                "so called 'Greatest Revolution.' It is the burning flame of Revolutionary Federalism which guides",
                                "the once darkened Orion spur. Emerging from the Great Galactic War as one of the two most powerful",
                                "nations in the galaxy, Orion faces many challenges, both domestic and international.", "", "",
                                "The political structure of the League is peculiar, a single People's Revolutionary Front has",
                                "ruled for a period of a century. While factionalism is officially banned within the party,",
                                "this has not stopped ideological division from rearing its head. In a break from its viscious war",
                                "with itself, the Front found itself in a viscious war with the Mlakh Rak, out of which emerged",
                                "the war hero Premier Julian Korolev. While basking in his laurels and holding utmost public acclaim,",
                                "rumors of centralism within his cabinet has begun to surface.", "", "",
                                "Within the Front itself have re-emerged various 'interest groups,' having exited their sudden truce.",
                                "The Conservatives, led by Niksa Dordevic maintain that the current political and social structure",
                                "of the League shall remain firmly intact, for now and forever, or at least for now.",
                                "The Ultrafederalists are the truest revolutionaries, at least according to them. Headed by Pat Jean,",
                                "they believe that State Autonomy and individual liberty is the ideal direction of the party.",
                                "The Reformists headed by Jackquelynn McKenna believe in the eventual liberalisation of the League",
                                "from its current state, while maintaining the guiding vision of the Revolution and its principles.",
                                "The Hardliners lead by one August Vega believe that the founders were not sufficient in creating",
                                "a true revolutionary vision, and they seek to impose their great vision."};
        
        orion = new Orion("The Common and United League of Orion", "orionflag.jpg", orionBlurb);
        selectedCountry = null;
        
        PopsimManager.initialise();
    }
    
    public void paintComponent(Graphics g)
    {
        super.paintComponent(g);
        
        switch(gameState)
        {
            case START:
                paintStart(g);
                break;
            case COUNTRY_SELECT:
                selectCountry(g);
                break;
            case GAME_PLAY:
                selectedCountry.gameScreen(g, basedFont);
                break;
        }
    }
    
    // UI design below
    private void paintStart(Graphics g)
    {
        Image image = null;
        try
        {
            image = ImageIO.read(new File("intropic.jpg")).getScaledInstance(800, 300, Image.SCALE_SMOOTH);
        } catch (IOException e)
        {
            e.printStackTrace();
        }
        
        g.drawImage(image, 300, 100, null);
        g.setColor(Color.RED);
        g.drawRect(300, 410, 800, 300);
        
        g.setFont(basedFont.deriveFont(68.0f));
        g.drawString("Twilight of the Ages", 300, 100);
        
        g.setFont(basedFont.deriveFont(18.0f));
        g.drawString("In the year 2600, the galaxy has just emerged from the burning flames of", 305, 430);
        g.drawString("war. Out of them burned away the old order of the Imperial State and", 305, 430 + g.getFontMetrics().getHeight());
        g.drawString("Mlakh Rak, and in its place forged a tumultuous world of the Rou'ii", 305, 430 + g.getFontMetrics().getHeight() * 2);
        g.drawString("and the League, each with their own vision for the galaxy, and each", 305, 430 + g.getFontMetrics().getHeight() * 3);
        g.drawString("believing the other to be a mortal danger to it. As friend becomes to foe", 305, 430 + g.getFontMetrics().getHeight() * 4);
        g.drawString("and brother turns on brother the future of the galaxy is unclear.", 305, 430 + g.getFontMetrics().getHeight() * 5);
        g.drawString("The only fact that is certain is that the war has yet to end.", 305, 430 + g.getFontMetrics().getHeight() * 6);
        
        g.drawRect(550, 600, 300, 100);
        g.setFont(basedFont.deriveFont(40.0f));
        g.drawString("To Victory!", 575, 670);
    }
    
    private void selectCountry(Graphics g)
    {
        g.setColor(Color.RED);
        if(selectedCountry == null)
        {
            g.drawRect(588, 100, 163, 92);
            g.drawImage(orion.getImage(), 589, 101, null);
        }
        if(selectedCountry == orion)
        {
            g.setFont(basedFont.deriveFont(60.0f));
            g.drawString("The Common and United League of Orion", 10, 60);
            
            g.drawRect(508, 100, 322, 182);
            g.drawImage(orion.getImage().getScaledInstance(320, 180, Image.SCALE_SMOOTH), 509, 101, null);
            
            g.setFont(basedFont.deriveFont(40.0f));
            g.drawString("Premier Julian Korolev", 10, 350);
            g.drawRect(10, 360, 520, 422);
            g.drawRect(540, 310, 800, 472);
            
            g.setFont(basedFont.deriveFont(14.0f));
            
            for(int i = 0; i < ((Orion) orion).getBlurbMessage().length; i++)
            {
                g.drawString(((Orion) orion).getBlurbMessage()[i], 550, 320 + g.getFontMetrics().getHeight() * (1 + i));
            }
            
            Image image = null;
            try
            {
                image = ImageIO.read(new File("korolev.png")).getScaledInstance(518, 420, Image.SCALE_SMOOTH);
            } catch (IOException e)
            {
                e.printStackTrace();
            }
            
            g.drawImage(image, 11, 361, null);
            
            g.drawRect(575, 800, 200, 100);
            g.setFont(basedFont.deriveFont(18.0f));
            g.drawString("The Fire of Freedom", 576, 850);
            g.drawString("Burns Bright", 610, 850 + g.getFontMetrics().getHeight());
        }
    }
    
    // Mouse stuff
    private class MouseInput implements MouseListener
    {
        public void mousePressed(MouseEvent e)
        {
            
        }
        
        public void mouseReleased(MouseEvent e)
        {
            
        }
        
        public void mouseClicked(MouseEvent e)
        {
            switch(gameState)
            {
                case START:
                    if(e.getX() > 550 && e.getX() < 850
                        && e.getY() > 600 && e.getY() < 700)
                            gameState = GameState.COUNTRY_SELECT;
                    break;
                case COUNTRY_SELECT:
                    if(e.getX() > 588 && e.getX() < 588+163
                        && e.getY() > 100 && e.getY() < 192 && selectedCountry == null)
                        selectedCountry = orion;
                    else if(selectedCountry == orion && e.getX() > 575 && e.getX() < 775
                                && e.getY() > 800 && e.getY() < 900)
                        gameState = GameState.GAME_PLAY;
                    break;
                case GAME_PLAY:
                    selectedCountry.processInput(e.getX(), e.getY());
                    break;
            }
            
            repaint();
        }
        
        public void mouseEntered(MouseEvent e)
        {
            
        }
        
        public void mouseExited(MouseEvent e)
        {
            
        }
    }
}
